<?php
/**
 * Plugin Name: EDU Live Course Micro for ELA ACADEMY
 * Description: Renders WooCommerce checkout but with Bangla fields for the EDU flow for ELA ACADEMY.
* Author: MD EMON SHARKAR (emonsharkar.2000@gmail.com)
 * Version: 2.0.0
 */


if ( ! defined('ABSPATH') ) exit;

define('EDU_LIVE_COURSE_SLUG', 'live-course'); // change if your category slug differs

// --- Helpers (handles simple + variations)
function _edu_item_in_live_cat( $product_id ) {
    $ids = array( (int)$product_id );
    $parent = wp_get_post_parent_id( $product_id );
    if ( $parent ) $ids[] = (int)$parent;
    foreach ( $ids as $id ) {
        if ( $id && has_term( EDU_LIVE_COURSE_SLUG, 'product_cat', $id ) ) return true;
    }
    return false;
}
function _edu_cart_has_live_cat() {
    if ( ! function_exists('WC') || ! WC()->cart ) return false;
    foreach ( WC()->cart->get_cart() as $item ) {
        $pid = (int) $item['product_id'];
        $vid = ! empty($item['variation_id']) ? (int)$item['variation_id'] : 0;
        if ( _edu_item_in_live_cat( $vid ?: $pid ) ) return true;
    }
    return false;
}

// Scope flag so filters apply ONLY when we want them
$GLOBALS['EDU_CHECKOUT_ACTIVE'] = false;
function _edu_is_active() { return !empty($GLOBALS['EDU_CHECKOUT_ACTIVE']); }

/**
 * Shortcode: [edu_checkout]
 * - If cart has Live Course -> activate custom Bangla fields and render checkout
 * - Else -> render the normal checkout (no changes)
 */
add_shortcode('edu_checkout', function () {
    if ( ! function_exists('WC') ) return '<p>WooCommerce is required.</p>';

    $has_live = _edu_cart_has_live_cat();

    if ( $has_live ) {
        $GLOBALS['EDU_CHECKOUT_ACTIVE'] = true;
        $html = do_shortcode('[woocommerce_checkout]');
        $GLOBALS['EDU_CHECKOUT_ACTIVE'] = false;
        return $html;
    }

    // No live-course in cart: render default checkout untouched
    return do_shortcode('[woocommerce_checkout]');
});

/** Change checkout fields ONLY when active (i.e., only for Live Course carts) */
add_filter('woocommerce_checkout_fields', function( $fields ) {
    if ( ! _edu_is_active() ) return $fields;

    // Remove address/company to keep it short
    foreach ([
        'billing_last_name','billing_company','billing_country',
        'billing_address_1','billing_address_2','billing_city',
        'billing_state','billing_postcode'
    ] as $key) { unset( $fields['billing'][ $key ] ); }

    // ১. শিক্ষার্থীর সম্পূর্ণ নাম (use billing_first_name)
    $fields['billing']['billing_first_name']['label']       = '১. শিক্ষার্থীর সম্পূর্ণ নাম';
    $fields['billing']['billing_first_name']['placeholder'] = '';
    $fields['billing']['billing_first_name']['required']    = true;
    $fields['billing']['billing_first_name']['priority']    = 10;
    $fields['billing']['billing_first_name']['class']       = ['form-row-wide'];

    // ২. শিক্ষার্থীর বয়স (new)
    $fields['billing']['billing_student_age'] = [
        'type'              => 'number',
        'label'             => '২. শিক্ষার্থীর বয়স',
        'required'          => true,
        'class'             => ['form-row-wide'],
        'priority'          => 12,
        'custom_attributes' => ['min' => 1, 'step' => 1],
    ];

    // ৩. পিতার নাম (new)
    $fields['billing']['billing_father_name'] = [
        'type'     => 'text',
        'label'    => '৩. শিক্ষার্থীর পিতার সম্পূর্ণ নাম',
        'required' => true,
        'class'    => ['form-row-wide'],
        'priority' => 14,
    ];

    // ৪. মাতার নাম (new)
    $fields['billing']['billing_mother_name'] = [
        'type'     => 'text',
        'label'    => '৪. শিক্ষার্থীর মাতার সম্পূর্ণ নাম',
        'required' => true,
        'class'    => ['form-row-wide'],
        'priority' => 16,
    ];

    // ৫. WhatsApp নাম্বার (reuse phone)
    $fields['billing']['billing_phone']['label']       = '৫. যোগাযোগের WHATSAPP নাম্বার';
    $fields['billing']['billing_phone']['required']    = true;
    $fields['billing']['billing_phone']['priority']    = 18;
    $fields['billing']['billing_phone']['class']       = ['form-row-wide'];
    $fields['billing']['billing_phone']['placeholder'] = '+8801XXXXXXXXX';

    // ৬. ই-মেইল (ঐচ্ছিক)
    $fields['billing']['billing_email']['label']    = '৬. ই-মেইল (ঐচ্ছিক)';
    $fields['billing']['billing_email']['required'] = false;
    $fields['billing']['billing_email']['priority'] = 20;

    // ৭. অতিরিক্ত নোট (placeholder)
    if ( isset($fields['order']['order_comments']) ) {
        $fields['order']['order_comments']['label']       = '৭. অতিরিক্ত নোট (ঐচ্ছিক)';
        $fields['order']['order_comments']['placeholder'] = 'আপনি কি কিছু জানাতে ইচ্ছুক?';
        $fields['order']['order_comments']['priority']    = 30;
    }

    // hidden flag so our validation/save only runs for Live Course carts
    $fields['billing']['edu_checkout_flag'] = [
        'type'     => 'hidden',
        'default'  => '1',
        'required' => false,
        'priority' => 1,
    ];

    return $fields;
});

/** Validate ONLY for our Live Course form */
add_action('woocommerce_after_checkout_validation', function( $posted, $errors ){
    if ( empty($_POST['edu_checkout_flag']) ) return;
    if ( empty($_POST['billing_student_age']) || intval($_POST['billing_student_age']) <= 0 ) {
        $errors->add( 'billing_student_age', __( 'শিক্ষার্থীর বয়স লিখুন।', 'edu' ) );
    }
    if ( empty($_POST['billing_father_name']) ) {
        $errors->add( 'billing_father_name', __( 'শিক্ষার্থীর পিতার সম্পূর্ণ নাম লিখুন।', 'edu' ) );
    }
    if ( empty($_POST['billing_mother_name']) ) {
        $errors->add( 'billing_mother_name', __( 'শিক্ষার্থীর মাতার সম্পূর্ণ নাম লিখুন।', 'edu' ) );
    }
}, 10, 2 );

/** Save custom fields ONLY for our Live Course form */
add_action('woocommerce_checkout_create_order', function( $order, $data ){
    if ( empty($_POST['edu_checkout_flag']) ) return;

    if ( isset($_POST['billing_student_age']) )
        $order->update_meta_data('edu_student_age', intval($_POST['billing_student_age']));
    if ( isset($_POST['billing_father_name']) )
        $order->update_meta_data('edu_father_name', sanitize_text_field($_POST['billing_father_name']));
    if ( isset($_POST['billing_mother_name']) )
        $order->update_meta_data('edu_mother_name', sanitize_text_field($_POST['billing_mother_name']));
}, 10, 2 );

/** Display in admin & emails */
add_action('woocommerce_admin_order_data_after_billing_address', function( $order ){
    $map = [
        'edu_student_age' => 'বয়স',
        'edu_father_name' => 'পিতার নাম',
        'edu_mother_name' => 'মাতার নাম',
    ];
    echo '<div class="edu-order-meta"><h3>ভর্তি তথ্য</h3><table>';
    foreach ($map as $k => $label) {
        $v = $order->get_meta($k);
        if ($v !== '') echo '<tr><th style="text-align:left">'.$label.':</th><td>'.esc_html($v).'</td></tr>';
    }
    echo '</table></div>';
}, 10, 1 );

add_action('woocommerce_email_order_meta', function( $order, $sent_to_admin, $plain ){
    $map = [
        'edu_student_age' => 'বয়স',
        'edu_father_name' => 'পিতার নাম',
        'edu_mother_name' => 'মাতার নাম',
    ];
    if ( $plain ) {
        echo "\nভর্তি তথ্য\n";
        foreach ($map as $k=>$label) { $v = $order->get_meta($k); if ($v!=='') echo "{$label}: {$v}\n"; }
    } else {
        echo '<h2>ভর্তি তথ্য</h2><ul>';
        foreach ($map as $k=>$label) { $v = $order->get_meta($k); if ($v!=='') echo '<li><strong>'.$label.':</strong> '.esc_html($v).'</li>'; }
        echo '</ul>';
    }
}, 10, 3 );
